# Verification materials for continuously tunable multiqubit elegant joint measurements

Archive version: **1.2.0**

This package accompanies **A unified construction of continuously tunable multiqubit elegant joint measurements**, by **Tingyu Zhang and Yan Cen**, Department of Physics, Fudan University, Shanghai, China.

Version 1.2.0 completes the Lean proofs of the all-size genuine multipartite entanglement formula and endpoint comparisons, and the arbitrary two-valued real-generator extension. These proofs start from the actual measurement columns and reduced matrices. The package also preserves the independent exact-arithmetic scripts and certificates for Appendix E1.

```text
multiqubit-ejm-verification-1.2.0/
  README.md
  LICENSE
  lean/                       # Local foundations and pinned dependencies
  lean-unified/               # Lean sources, coverage map, and audit programs
  verification/               # Final theorem and full declaration audits
  verification.json           # Verification summary for this release
  reproduce/all_n_gme/         # Appendix E1 scripts and certificates
```

Keep `lean/` and `lean-unified/` adjacent. External dependencies and compiled caches are not bundled.

## Lean verification

The main entry is `lean-unified/UnifiedEJM.lean`. See [COVERAGE.md](lean-unified/COVERAGE.md) for precise declaration names and assumptions. The new `AllNEntanglement.measurement_gme` theorem establishes

\[
C_{\mathrm{GME}}=\sqrt{1-r_n(t)^2}>0
\]

for every integer `n ≥ 5`, every real parameter, and every measurement column. Its associated theorems identify the minimizing cuts and exclude product states across every nontrivial partition. The zero-radius endpoint is outside all stabilizer-state local-unitary and permutation orbits; for every even `n ≥ 6`, it is also inequivalent to the cosine-family zero-radius endpoint, allowing independent outcome labels and a global phase.

The all-size Lean proof uses finite verification for `n = 5, ..., 8`, a stronger perturbation bound valid from `n = 9`, an induction for arbitrary-length background states, and exact prefix-cut coefficient proofs. This is a proof of the same all-size result by a different reduction from the paper's finite `n = 5, ..., 9` computation. The 456 Python cut checks have not all been individually ported to Lean.

With Git and elan/Lean installed, run from `lean-unified/`:

```text
lake exe cache get
lake build
lake env lean Audit.lean
lake env lean AllAxioms.lean
```

Lean **4.35.0** and mathlib **v4.35.0** are pinned by the toolchain and manifests; the mathlib commit is `56a005855ea17e0b0958f73ec801ae140b0a1679`. A fresh setup requires network access. The internal Lake package versions remain `0.1.0`.

`Audit.lean` reports selected declaration types and their axiom dependencies. `AllAxioms.lean` checks every imported local declaration, including private and generated declarations, and rejects dependencies outside `propext`, `Classical.choice`, and `Quot.sound`. The supplied audit outputs and `verification.json` record this release's checks.

## Independent Appendix E1 reproduction

See [the certificate instructions](reproduce/all_n_gme/README.md). With Python **3.10 or later** and NumPy installed, run from the archive root:

```text
python -B reproduce/all_n_gme/verify.py
```

Run without Python's `-O` option. The scripts reconstruct the finite certificates using arbitrary-precision integers and rational arithmetic. They cover the rank-one length formulas, 7,882 compressed representatives, the independent closure certificate, all 456 non-single-qubit cuts for `n = 5, ..., 9`, and endpoint purity checks. Their saved results are preserved from the earlier verification; the complete Python computation was not rerun for this Lean update.

Packaging checks validate all local imports, pinned configuration, relative dependency paths, and successful extraction of every file. The [project repository](https://github.com/emmm1e3m/odd-qubit-ejm) distributes the bilingual paper separately.

## License

The archive is distributed under the [MIT License](LICENSE), copyright 2026 Tingyu Zhang and Yan Cen. Third-party dependencies retain their own licenses.
