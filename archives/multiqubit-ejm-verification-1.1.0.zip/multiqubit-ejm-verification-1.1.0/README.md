# Verification materials for continuously tunable multiqubit elegant joint measurements

Archive version: **1.1.0**

This package accompanies **A unified construction of continuously tunable multiqubit elegant joint measurements**, by **Tingyu Zhang and Yan Cen**, Department of Physics, Fudan University, Shanghai, China.

It contains the current Lean proof sources, their local foundation modules and pinned dependency configuration, the existing axiom-audit programs, and the exact-arithmetic certificates and scripts used in Appendix E1. Compared with version 1.0.0, this release adds the later production physics modules and the self-contained all-n concurrence certificate package.

```text
multiqubit-ejm-verification-1.1.0/
  README.md
  LICENSE
  lean/                       # OddEJM foundation and dependency configuration
  lean-unified/               # UnifiedEJM sources and axiom-audit programs
  reproduce/all_n_gme/        # Appendix E1 scripts, certificates, and instructions
```

Keep `lean/` and `lean-unified/` adjacent: the latter depends on `../lean`. External libraries and compiled caches are retrieved during setup and are not bundled.

## Lean sources

The main entry is `lean-unified/UnifiedEJM.lean`. The source tree includes the unified measurement construction, the Boolean phase-path bound, the even-qubit embedding, low-dimensional results, reduced-state invariants, and the production entanglement and circuit modules. Declaration types give the precise assumptions and quantifiers; Lean uses zero-based qubit indices.

With Git and elan/Lean installed, run from `lean-unified/`:

```text
lake exe cache get
lake build
lake env lean Audit.lean
lake env lean AllAxioms.lean
```

The toolchain is Lean **4.35.0**. The manifests pin mathlib **v4.35.0**, commit `56a005855ea17e0b0958f73ec801ae140b0a1679`, and the other external dependencies. A fresh setup requires network access. The internal Lake package version fields remain `0.1.0`; the archive version is `1.1.0`.

`Audit.lean` reports selected declaration types and axiom dependencies. `AllAxioms.lean` checks all imported local declarations and rejects dependencies outside the standard axioms `propext`, `Classical.choice`, and `Quot.sound`.

## Appendix E1 certificates

See [`reproduce/all_n_gme/README.md`](reproduce/all_n_gme/README.md) for the full coverage and algorithm. With Python **3.10 or later** and NumPy installed, run from the archive root:

```text
python -B reproduce/all_n_gme/verify.py
```

Run without Python's `-O` option. The script uses arbitrary-precision integer and rational arithmetic and reconstructs the finite certificates; it does not sample the continuous parameter. It verifies:

- Rank-one length polynomials, including parity and short-length cases.
- All 7,882 compressed representatives for crossing rank 2, 3, and 4 (259, 1,332, and 6,291 representatives), their coefficient classes, and multiplicities.
- The independent closure certificate with 1,405 states and 1,313 terminal signatures.
- All 456 non-single-qubit cuts for `n = 5, ..., 9`, reconstructed from the original gates.
- The amplitude bridge and zero-radius two-qubit purity formulas.

The manuscript supplies the analytic reductions covering arbitrary `n` and the high-rank and large-`n` tail bounds. The Python package provides independent exact-arithmetic reproduction of the finite computations. These scripts are a separate verification route from the Lean build; their successful execution is not a Lean kernel check.

## Packaging and existing results

This release includes the existing `reproduce/all_n_gme/verification_results.json`. Packaging checks validate the local import closure, relative dependency paths, pinned configuration, complete certificate file set, and extraction of every archived file. The Lean build, axiom audit, and full certificate computation were not rerun during packaging.

The paper and project are available in the [project repository](https://github.com/emmm1e3m/odd-qubit-ejm).

## License

The archive is distributed under the [MIT License](LICENSE), copyright 2026 Tingyu Zhang and Yan Cen. Third-party dependencies retain their own licenses.
